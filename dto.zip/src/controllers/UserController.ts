import { Request, Response, NextFunction } from "express";
import { autoInjectable } from "tsyringe";
import UserService from "../services/UserService";
import ApiError from "../errors/ApiError";
import { CreateUserDTO } from "../dtos/createUser.schema";

@autoInjectable()
export default class UserController {
  constructor(private userService?: UserService) {}

  register = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const dto = req.body as CreateUserDTO;
      const user = await this.userService!.registerUser(dto);
      return res.status(201).json({ success: true, data: user });
    } catch (err: any) {
      if (err.message === "User already exists") {
        return next(new ApiError("USER_EXISTS", "User already exists", 409));
      }
      return next(err);
    }
  };

  list = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const users = await this.userService!.listUsers();
      return res.json({ success: true, data: users });
    } catch (err) {
      return next(err);
    }
  };

  getById = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const id = req.params.id as string;
      const user = await this.userService!.getUserById(id);
      return res.json({ success: true, data: user });
    } catch (err) {
      return next(err);
    }
  };

  update = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const id = req.params.id as string;
      const payload = req.body;
      const user = await this.userService!.updateUser(id, payload);
      return res.json({ success: true, data: user });
    } catch (err) {
      return next(err);
    }
  };

  delete = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const id = req.params.id as string;
      const result = await this.userService!.deleteUser(id);
      return res.json(result);
    } catch (err) {
      return next(err);
    }
  };
}
