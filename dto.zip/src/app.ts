import "reflect-metadata"; // required by tsyringe
import express from "express";
import "./container"; // register DI bindings
import usersRouter from "./routes/users";
const app = express();
app.use(express.json());

app.use("/users", usersRouter);

// centralized error handler (must be last)
app.use((err: any, req: express.Request, res: express.Response, next: express.NextFunction) => {
  // Log the error for debugging/monitoring
  console.error(err);

  // Default to 500 if status not set
  const status = err?.status || 500;
  const message = err?.message || "Internal Server Error";

  res.status(status).json({ error: message });
});

import { mountSwagger } from "./swagger"; // Import mountSwagger here

// swagger UI
mountSwagger(app); // Mount Swagger UI at /docs
export default app;
