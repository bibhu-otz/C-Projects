import { container } from "tsyringe";
import { UserRepositoryInMemory } from "./infra/userRepository.inMemory";
import UserService from "./services/UserService";

// Register the in-memory repository as the implementation for "UserRepository" token
container.register("UserRepository", { useClass: UserRepositoryInMemory });
container.registerSingleton(UserService);
