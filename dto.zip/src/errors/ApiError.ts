export default class ApiError extends Error {
  public code: string;
  public status: number;
  public details?: unknown;

  constructor(code = "INTERNAL_ERROR", message = "Internal server error", status = 500, details?: unknown) {
    super(message);
    this.code = code;
    this.status = status;
    this.details = details;
    Object.setPrototypeOf(this, ApiError.prototype);
  }
}
