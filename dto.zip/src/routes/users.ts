import { Router } from "express";
import UserController from "../controllers/UserController";
import { validate } from "../middlewares/validate";
import { CreateUserSchema } from "../dtos/createUser.schema";
import { container } from "tsyringe";

const router = Router();
const controller = container.resolve(UserController);

router.post("/register", validate(CreateUserSchema, "body"), controller.register);
router.get("/", controller.list);
router.get("/:id", controller.getById);
router.put("/:id", validate(CreateUserSchema.partial(), "body"), controller.update);
router.delete("/:id", controller.delete);

export default router;
