import { injectable } from "tsyringe";
import { CreateUserDTO } from "../dtos/createUser.schema";

@injectable()
export class UserRepositoryInMemory {
  private users: Array<any> = [];

  async findByEmail(email: string) {
    return this.users.find(u => u.email === email) ?? null;
  }

  async createUser(user: any) {
    // simulate a DB unique constraint on email
    const exists = await this.findByEmail(user.email);
    if (exists) {
      const err: any = new Error("Duplicate email");
      // set a code that higher-level service can interpret
      err.code = "USER_DUPLICATE";
      throw err;
    }

    this.users.push(user);
    return user;
  }

  async findById(id: string) {
    return this.users.find(u => u.id === id) ?? null;
  }

  async listUsers() {
    // return a shallow copy
    return this.users.map(u => ({ ...u }));
  }

  async updateUser(id: string, patch: Partial<any>) {
    const idx = this.users.findIndex(u => u.id === id);
    if (idx === -1) {
      const err: any = new Error('Not found');
      err.code = 'NOT_FOUND';
      throw err;
    }
    this.users[idx] = { ...this.users[idx], ...patch };
    return this.users[idx];
  }

  async deleteUser(id: string) {
    const idx = this.users.findIndex(u => u.id === id);
    if (idx === -1) return false;
    this.users.splice(idx, 1);
    return true;
  }
}
