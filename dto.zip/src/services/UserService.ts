import { injectable, inject } from "tsyringe";
import bcrypt from "bcryptjs";
import { CreateUserDTO, UpdateUserDTO } from "../dtos/createUser.schema";
import ApiError from "../errors/ApiError";

export interface IUserRepository {
  createUser(user: CreateUserDTO & { id: string }): Promise<any>;
  findByEmail(email: string): Promise<any | null>;
  findById(id: string): Promise<any | null>;
  listUsers(): Promise<any[]>;
  updateUser(id: string, patch: Partial<any>): Promise<any>;
  deleteUser(id: string): Promise<boolean>;
}

@injectable()
export default class UserService {
  constructor(@inject("UserRepository") private repo: IUserRepository) {}

  async registerUser(payload: CreateUserDTO) {
    // hash password before sending to repo
    const hashed = await bcrypt.hash(payload.password, 10);
    const user = { ...payload, password: hashed, id: (Math.random() * 1e9).toFixed(0) };

    try {
      await this.repo.createUser(user);
      const { password: _p, ...safe } = user as any;
      return safe;
    } catch (err: any) {
      // Map repository duplicate error to ApiError with 409
      if (err && (err.code === "USER_DUPLICATE" || err.code === "ER_DUP_ENTRY" || err.code === "P2002")) {
        throw new ApiError("USER_EXISTS", "User already exists", 409);
      }
      // rethrow other errors
      throw err;
    }
  }

  async listUsers() {
    const users = await this.repo.listUsers();
    return users.map((u: any) => {
      const { password, ...safe } = u;
      return safe;
    });
  }

  async getUserById(id: string) {
    const user = await this.repo.findById(id);
    if (!user) {
      throw new ApiError('NOT_FOUND', 'User not found', 404);
    }
    const { password, ...safe } = user as any;
    return safe;
  }

  async updateUser(id: string, patch: UpdateUserDTO) {
    // if password present, hash it
    const updatePayload: any = { ...patch };
    if (patch.password) {
      updatePayload.password = await bcrypt.hash(patch.password, 10);
    }
    try {
      const updated = await this.repo.updateUser(id, updatePayload);
      const { password, ...safe } = updated as any;
      return safe;
    } catch (err: any) {
      if (err && err.code === 'NOT_FOUND') {
        throw new ApiError('NOT_FOUND', 'User not found', 404);
      }
      throw err;
    }
  }

  async deleteUser(id: string) {
    const ok = await this.repo.deleteUser(id);
    if (!ok) {
      throw new ApiError('NOT_FOUND', 'User not found', 404);
    }
    return { success: true };
  }
}
