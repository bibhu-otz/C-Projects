import { z } from "zod";

export const CreateUserSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  fullName: z.string().optional()
});

export type CreateUserDTO = z.infer<typeof CreateUserSchema>;

export const UpdateUserSchema = CreateUserSchema.partial().extend({
  password: z.string().min(8).optional(),
});

export type UpdateUserDTO = z.infer<typeof UpdateUserSchema>;

export const UserResponseSchema = CreateUserSchema.omit({ password: true }).extend({ id: z.string() });
export type UserResponse = z.infer<typeof UserResponseSchema>;
