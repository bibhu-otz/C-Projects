import { NextFunction, Request, Response } from "express";
import { ZodSchema } from "zod";
import ApiError from "../errors/ApiError";

// source can be 'body' | 'query' | 'params'
export function validate(schema: ZodSchema<any>, source: "body" | "query" | "params" = "body") {
  return (req: Request, res: Response, next: NextFunction) => {
    const parsed = schema.safeParse(req[source]);
    if (!parsed.success) {
      const details = parsed.error.issues.map(i => ({
        path: i.path.join('.'),
        message: i.message,
      }));
      return next(new ApiError("VALIDATION_ERROR", "Invalid input", 400, details));
    }

    // Overwrite with parsed data for downstream type-safety
    req[source] = parsed.data;
    return next();
  };
}
