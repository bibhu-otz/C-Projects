import { NextFunction, Request, Response } from "express";
import ApiError from "../errors/ApiError";

export default function errorHandler(err: any, req: Request, res: Response, next: NextFunction) {
  if (err instanceof ApiError) {
    const payload = {
      success: false,
      error: {
        code: err.code,
        message: err.message,
        details: err.details ?? []
      }
    };
    return res.status(err.status).json(payload);
  }

  console.error(err);
  return res.status(500).json({
    success: false,
    error: {
      code: "INTERNAL_ERROR",
      message: "Something went wrong",
      details: []
    }
  });
}
