# DTOs, Validation & Error Handling — Training Guide

A complete, printable training document for a live session on building robust Node.js APIs using TypeScript.

This document includes: slides and trainer notes, full code snippets for a minimal demo project (Zod DTOs, validation middleware, centralized error handling, ApiError shape), dependency injection using `tsyringe`, and run instructions for Windows CMD.

---

## Session Overview

Title: DTOs, Validation & Error Handling — Building Robust Node.js APIs using TypeScript

Trainer explanation: Today we’ll learn how professional backend teams design APIs that are predictable, secure, and easy to maintain. This is not just coding — this is engineering discipline.

Audience: Tech leads and developers who already know basic API routing and separation of concerns.

Duration: 60–90 minutes (includes live coding/demo and Q&A)

---
    ApiError.ts
# Workshop: DTOs, Validation & Error Handling — Hands-on Guide

This is a workshop-style training document designed to let you teach concepts and code together, step-by-step, in an engaging and repeatable flow.

Goals for participants (by end of the workshop):
- Understand DTOs as API contracts and how they protect your codebase.
- Build and reuse Zod schemas for runtime validation with TypeScript types.
- Centralize error handling and provide a consistent JSON error shape.
- Use dependency injection (tsyringe) to make services testable and replaceable.
- Implement secure user registration with password hashing and duplicate handling.

Audience: Tech leads and senior developers familiar with Node.js and TypeScript who want practical patterns they can apply immediately.

Total time: 75–90 minutes (can be split into two sessions). Each major section includes a short live-coding exercise and an optional quick challenge for participants.

What you'll need before the session:
- Node.js (18+ recommended)
- A terminal (Windows: cmd or PowerShell)
- Editor (VS Code recommended)
- Project scaffold in `d:\\nn-demo\\dto` (this repo already contains the starter files)

Quick setup commands (paste into Windows CMD in project root):

```cmd
cd /d d:\\nn-demo\\dto
npm install
npm run dev
```

If you prefer to compile and run the dist build:

```cmd
npx tsc -p tsconfig.json
node dist/server.js
```

Section layout — how we will run the workshop
- 5m Intro + objectives
- 20m DTOs & Zod (concept + implement schema + middleware)
- 15m Centralized error handling (ApiError + middleware)
- 15m Dependency Injection + Service wiring (tsyringe)
- 15m Case study: User registration (hash password + duplicate handling)
- 5–10m Wrap-up, Q&A, and next steps

Tips for an enjoyable flow
- Alternate between 5–10 minutes of code and 2–3 minutes of explanation.
- Ask one targeted question after each demo (e.g., "How would you map a DB error to an ApiError?").
- Use the quick challenges as short exercises for pairs. They take 2–4 minutes each.

---

## Section A — DTOs & Zod (20 minutes)

Concept (2 minutes)
- DTOs are contracts: they declare allowed fields and types at the boundary of your application. Use Zod to get runtime validation and TypeScript types from one schema.

Live coding (12 minutes)
1. Open `src/dtos/createUser.schema.ts` and implement the schema if not present.

Snippet (already in repo):

```ts
import { z } from "zod";

export const CreateUserSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  fullName: z.string().optional()
});

export type CreateUserDTO = z.infer<typeof CreateUserSchema>;
```

2. Explain `z.infer` and how IDEs will now show types when using `CreateUserDTO`.

Exercise (quick challenge, 3 min)
- Add a `role` field to the schema that is optional and must be one of `"user" | "admin"`.

Checkpoint (1 min)
- Run a quick curl with invalid email to see Zod errors be triggered by the middleware (we’ll wire the middleware next).

---

## Section B — Validation middleware (10 minutes)

Concept (1 min)
- Keep validation logic out of controllers. Use a reusable middleware `validate(schema, source)`.

Live coding (6 minutes)
- Open `src/middlewares/validate.ts`. The key behavior:
  - Use `schema.safeParse()`
  - If invalid: create an `ApiError("VALIDATION_ERROR", ..., 400, details)` and call `next(err)`
  - If valid: replace `req[source]` with `parsed.data` to provide typed data downstream.

Snippet (already in repo):

```ts
import { NextFunction, Request, Response } from "express";
import { ZodSchema } from "zod";
import ApiError from "../errors/ApiError";

export function validate(schema: ZodSchema<any>, source: "body" | "query" | "params" = "body") {
  return (req: Request, res: Response, next: NextFunction) => {
    const parsed = schema.safeParse(req[source]);
    if (!parsed.success) {
      const details = parsed.error.issues.map(i => ({ path: i.path.join('.'), message: i.message }));
      return next(new ApiError("VALIDATION_ERROR", "Invalid input", 400, details));
    }
    req[source] = parsed.data;
    return next();
  };
}
```

Exercise (2 min)
- Call `POST /users/register` with a short password. Show the error JSON returned by `errorHandler`.

---

## Section C — Centralized error handling (15 minutes)

Concept (2 min)
- Centralizing error handling gives consistent API responses, easy monitoring, and single place to scrub/translate errors.

Live coding (8 minutes)
- Open `src/errors/ApiError.ts` and `src/middlewares/errorHandler.ts`.
- `ApiError` carries `code`, `status`, `message`, and `details`.

ApiError snippet:

```ts
export default class ApiError extends Error {
  public code: string;
  public status: number;
  public details?: unknown;

  constructor(code = "INTERNAL_ERROR", message = "Internal server error", status = 500, details?: unknown) {
    super(message);
    this.code = code;
    this.status = status;
    this.details = details;
    Object.setPrototypeOf(this, ApiError.prototype);
  }
}
```

Error handler snippet:

```ts
export default function errorHandler(err: any, req: Request, res: Response, next: NextFunction) {
  if (err instanceof ApiError) {
    return res.status(err.status).json({ success: false, error: { code: err.code, message: err.message, details: err.details ?? [] } });
  }
  console.error(err);
  return res.status(500).json({ success: false, error: { code: "INTERNAL_ERROR", message: "Something went wrong", details: [] } });
}
```

Exercise (3 min)
- Trigger a server error (e.g., throw new Error("boom") in the controller) and show it is handled uniformly.

Trainer tip: emphasize not to leak stack traces in production.

---

## Section D — Dependency Injection (tsyringe) (15 minutes)

Concept (2 min)
- DI allows replacing implementations easily for tests or env-specific wiring without changing consumers.

Live coding (10 minutes)
- Open `src/container.ts`, `src/services/UserService.ts`, `src/infra/userRepository.inMemory.ts`, and `src/controllers/UserController.ts`.
- Show that `container.register("UserRepository", { useClass: UserRepositoryInMemory })` wires the concrete repo for injection.

Key snippets (already in repo):

container registration:

```ts
import { container } from "tsyringe";
import { UserRepositoryInMemory } from "./infra/userRepository.inMemory";
import UserService from "./services/UserService";

container.register("UserRepository", { useClass: UserRepositoryInMemory });
container.registerSingleton(UserService);
```

Controller resolution in routes:

```ts
import { container } from "tsyringe";
const controller = container.resolve(UserController);
router.post("/register", validate(CreateUserSchema, "body"), controller.register);
```

Exercise (3 min)
- Replace `UserRepositoryInMemory` with a simple mock implementation (in code) and run the registration to show it still works.

---

## Section E — Case study: User registration (hashing + duplicate handling) (15 minutes)

Concept (2 min)
- Security: never store raw passwords. Hash with bcrypt. When DB signals duplicate entries, map those errors into a friendly `ApiError`.

Live coding (10 minutes)
- Open `src/services/UserService.ts`.
- The service now hashes password with `bcryptjs` before calling the repository.
- The in-memory repository simulates a DB duplicate by throwing an error with `err.code = "USER_DUPLICATE"` and the service maps that to `new ApiError("USER_EXISTS", "User already exists", 409)`.

Key snippet (already in repo):

```ts
import bcrypt from "bcryptjs";
import ApiError from "../errors/ApiError";

async registerUser(payload: CreateUserDTO) {
  const hashed = await bcrypt.hash(payload.password, 10);
  const user = { ...payload, password: hashed, id: String(Date.now()) };
  try {
    await this.repo.createUser(user);
    const { password: _p, ...safe } = user as any;
    return safe;
  } catch (err: any) {
    if (err && (err.code === "USER_DUPLICATE" || err.code === "ER_DUP_ENTRY" || err.code === "P2002")) {
      throw new ApiError("USER_EXISTS", "User already exists", 409);
    }
    throw err;
  }
}
```

Exercise (3 min)
- Register a user, then register the same email again — show 409 response and standardized shape.

---

## Short hands-on challenges (optional takeaways)

1. Make validation strict: disallow extra fields using `CreateUserSchema.strict()` and see how extra fields are rejected.
2. Add a `birthdate` field and validate it is an ISO date and in the past.
3. Add a `GET /users/:id` route guarded by a `findById` repo method and return 404 via `ApiError("NOT_FOUND", "User not found", 404)`.

Each challenge is 5–8 minutes for pairs.

---

## Tests & verification (brief)

Add one integration test with Supertest and Jest verifying:
- Successful registration returns 201 and no password in the payload.
- Duplicate registration returns 409 with `code: "USER_EXISTS"`.

Example test sketch (not added to repo automatically):

```ts
import request from "supertest";
import app from "../src/app";

test('register and duplicate', async () => {
  const payload = { email: 't@t.com', password: 'password123' };
  const r1 = await request(app).post('/users/register').send(payload);
  expect(r1.status).toBe(201);
  expect(r1.body.data.password).toBeUndefined();

  const r2 = await request(app).post('/users/register').send(payload);
  expect(r2.status).toBe(409);
  expect(r2.body.error.code).toBe('USER_EXISTS');
});
```

---

## Troubleshooting tips (common issues during demo)

- If DI fails to resolve a token, ensure `container.register(...)` runs before you `container.resolve(...)` (import order matters).
- If Zod errors don't show, ensure `validate()` middleware is used on the route.
- If passwords appear in responses, make sure services are removing `password` before returning.

---

## Trainer notes & pacing cues

- Keep each live coding block to ~8 minutes: implement, run, and show results.
- Use the quick challenge to involve the audience.
- For a longer workshop: expand the DB section to include Prisma and migration commands.

---

## One-page cheat sheet (printable)

- Use Zod as single source of truth for validation and typing.
- Validate at the edge with middleware: keep controllers thin.
- Map domain/DB errors to `ApiError` with stable `code` values for clients/monitoring.
- Use DI for easy substitution and testing.
- Hash secrets (bcrypt) and never return them in responses.

---

If you want, I can now:
- Expand the repo with Jest + Supertest tests and add npm test scripts. OR
- Add a short Prisma example (schema + service wiring) showing real DB error mapping. OR
- Convert this Markdown to a print-ready PDF and place it in the project folder.

Tell me which follow-up you prefer and I will implement it next.

_End of enhanced training guide_
```
