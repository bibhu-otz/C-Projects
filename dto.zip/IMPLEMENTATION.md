# Full Implementation Guide — DTOs, Validation & Error Handling (Node.js + TypeScript)

This document walks you through building the complete demo project from scratch. It includes step-by-step instructions, the exact file contents to create, run instructions, and verification steps. Use this to reproduce the project or as classroom material.

Project goal: A small user-management API (create/list/get/update/delete users) showing:
- DTOs using Zod
- Centralized validation middleware
- Centralized error handling (ApiError)
- Dependency Injection (tsyringe)
- Password hashing (bcryptjs)
- Swagger docs (OpenAPI)

Target runtime: Node.js 18+ and TypeScript

Workspace root: `d:\nn-demo\dto` (adjust paths if you pick a different folder)

---

## 1) Initialize project

1. Create directory and initialize npm:

```cmd
mkdir d:\nn-demo\dto
cd /d d:\nn-demo\dto
npm init -y
```

2. Install runtime and dev dependencies:

```cmd
npm install express zod tsyringe reflect-metadata bcryptjs swagger-ui-express swagger-jsdoc openapi-types
npm install -D typescript ts-node-dev @types/express @types/bcryptjs @types/swagger-ui-express
```

3. Create `tsconfig.json` (below) and `package.json` scripts.

---

## 2) Project files (create these file-by-file)

Below are the exact files and contents to create. Put them under `d:\nn-demo\dto`.

### package.json

Create `package.json` (adjust version strings if needed):

```json
{
  "name": "dto-zod-di-demo",
  "version": "1.0.0",
  "scripts": {
    "dev": "ts-node-dev --respawn --transpile-only src/server.ts",
    "build": "tsc",
    "start": "node dist/server.js"
  },
  "dependencies": {
    "bcryptjs": "^2.4.3",
    "express": "^4.18.2",
    "reflect-metadata": "^0.1.13",
    "tsyringe": "^4.8.0",
    "zod": "^3.22.2",
    "swagger-ui-express": "^4.6.3",
    "swagger-jsdoc": "^6.2.8",
    "openapi-types": "^9.4.0"
  },
  "devDependencies": {
    "@types/bcryptjs": "^2.4.6",
    "@types/express": "^4.17.17",
    "@types/swagger-ui-express": "^4.1.6",
    "ts-node-dev": "^2.0.0",
    "typescript": "^5.2.2"
  }
}
```

### tsconfig.json

Create `tsconfig.json` with the compiler options used in this project:

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "module": "CommonJS",
    "moduleResolution": "node",
    "esModuleInterop": true,
    "emitDecoratorMetadata": true,
    "experimentalDecorators": true,
    "outDir": "dist",
    "strict": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true
  },
  "include": ["src"]
}
```

---

Create the `src` directory and the following files inside it.

### src/app.ts

```ts
import "reflect-metadata"; // required by tsyringe
import express from "express";
import "./container"; // register DI bindings
import usersRouter from "./routes/users";
import errorHandler from "./middlewares/errorHandler";
import { mountSwagger } from "./swagger";

const app = express();
app.use(express.json());

// mount routes
app.use("/users", usersRouter);

// swagger UI
mountSwagger(app);

// centralized error handler (must be last)
app.use(errorHandler);

export default app;
```

### src/server.ts

```ts
import app from "./app";

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server listening on ${port}`);
});
```

### src/container.ts

```ts
import { container } from "tsyringe";
import { UserRepositoryInMemory } from "./infra/userRepository.inMemory";
import UserService from "./services/UserService";

// Register concrete implementations
container.register("UserRepository", { useClass: UserRepositoryInMemory });
container.registerSingleton(UserService);
```

### src/dtos/createUser.schema.ts

```ts
import { z } from "zod";

export const CreateUserSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8),
  fullName: z.string().optional()
});

export type CreateUserDTO = z.infer<typeof CreateUserSchema>;

export const UpdateUserSchema = CreateUserSchema.partial().extend({
  password: z.string().min(8).optional(),
});

export type UpdateUserDTO = z.infer<typeof UpdateUserSchema>;

export const UserResponseSchema = CreateUserSchema.omit({ password: true }).extend({ id: z.string() });
export type UserResponse = z.infer<typeof UserResponseSchema>;
```

### src/errors/ApiError.ts

```ts
export default class ApiError extends Error {
  public code: string;
  public status: number;
  public details?: unknown;

  constructor(code = "INTERNAL_ERROR", message = "Internal server error", status = 500, details?: unknown) {
    super(message);
    this.code = code;
    this.status = status;
    this.details = details;
    Object.setPrototypeOf(this, ApiError.prototype);
  }
}
```

### src/middlewares/validate.ts

```ts
import { NextFunction, Request, Response } from "express";
import { ZodSchema } from "zod";
import ApiError from "../errors/ApiError";

export function validate(schema: ZodSchema<any>, source: "body" | "query" | "params" = "body") {
  return (req: Request, res: Response, next: NextFunction) => {
    const parsed = schema.safeParse(req[source]);
    if (!parsed.success) {
      const details = parsed.error.issues.map(i => ({ path: i.path.join('.'), message: i.message }));
      return next(new ApiError("VALIDATION_ERROR", "Invalid input", 400, details));
    }
    req[source] = parsed.data;
    return next();
  };
}
```

### src/middlewares/errorHandler.ts

```ts
import { NextFunction, Request, Response } from "express";
import ApiError from "../errors/ApiError";

export default function errorHandler(err: any, req: Request, res: Response, next: NextFunction) {
  if (err instanceof ApiError) {
    const payload = {
      success: false,
      error: {
        code: err.code,
        message: err.message,
        details: err.details ?? []
      }
    };
    return res.status(err.status).json(payload);
  }

  console.error(err);
  return res.status(500).json({
    success: false,
    error: {
      code: "INTERNAL_ERROR",
      message: "Something went wrong",
      details: []
    }
  });
}
```

### src/infra/userRepository.inMemory.ts

```ts
import { injectable } from "tsyringe";

@injectable()
export class UserRepositoryInMemory {
  private users: Array<any> = [];

  async findByEmail(email: string) {
    return this.users.find(u => u.email === email) ?? null;
  }

  async createUser(user: any) {
    // simulate a DB unique constraint on email
    const exists = await this.findByEmail(user.email);
    if (exists) {
      const err: any = new Error("Duplicate email");
      err.code = "USER_DUPLICATE";
      throw err;
    }

    this.users.push(user);
    return user;
  }

  async findById(id: string) {
    return this.users.find(u => u.id === id) ?? null;
  }

  async listUsers() {
    return this.users.map(u => ({ ...u }));
  }

  async updateUser(id: string, patch: Partial<any>) {
    const idx = this.users.findIndex(u => u.id === id);
    if (idx === -1) {
      const err: any = new Error('Not found');
      err.code = 'NOT_FOUND';
      throw err;
    }
    this.users[idx] = { ...this.users[idx], ...patch };
    return this.users[idx];
  }

  async deleteUser(id: string) {
    const idx = this.users.findIndex(u => u.id === id);
    if (idx === -1) return false;
    this.users.splice(idx, 1);
    return true;
  }
}
```

### src/services/UserService.ts

```ts
import { injectable, inject } from "tsyringe";
import bcrypt from "bcryptjs";
import { CreateUserDTO, UpdateUserDTO } from "../dtos/createUser.schema";
import ApiError from "../errors/ApiError";

export interface IUserRepository {
  createUser(user: CreateUserDTO & { id: string }): Promise<any>;
  findByEmail(email: string): Promise<any | null>;
  findById(id: string): Promise<any | null>;
  listUsers(): Promise<any[]>;
  updateUser(id: string, patch: Partial<any>): Promise<any>;
  deleteUser(id: string): Promise<boolean>;
}

@injectable()
export default class UserService {
  constructor(@inject("UserRepository") private repo: IUserRepository) {}

  async registerUser(payload: CreateUserDTO) {
    const hashed = await bcrypt.hash(payload.password, 10);
    const user = { ...payload, password: hashed, id: (Math.random() * 1e9).toFixed(0) };

    try {
      await this.repo.createUser(user);
      const { password: _p, ...safe } = user as any;
      return safe;
    } catch (err: any) {
      if (err && (err.code === "USER_DUPLICATE" || err.code === "ER_DUP_ENTRY" || err.code === "P2002")) {
        throw new ApiError("USER_EXISTS", "User already exists", 409);
      }
      throw err;
    }
  }

  async listUsers() {
    const users = await this.repo.listUsers();
    return users.map((u: any) => {
      const { password, ...safe } = u;
      return safe;
    });
  }

  async getUserById(id: string) {
    const user = await this.repo.findById(id);
    if (!user) {
      throw new ApiError('NOT_FOUND', 'User not found', 404);
    }
    const { password, ...safe } = user as any;
    return safe;
  }

  async updateUser(id: string, patch: UpdateUserDTO) {
    const updatePayload: any = { ...patch };
    if (patch.password) {
      updatePayload.password = await bcrypt.hash(patch.password, 10);
    }
    try {
      const updated = await this.repo.updateUser(id, updatePayload);
      const { password, ...safe } = updated as any;
      return safe;
    } catch (err: any) {
      if (err && err.code === 'NOT_FOUND') {
        throw new ApiError('NOT_FOUND', 'User not found', 404);
      }
      throw err;
    }
  }

  async deleteUser(id: string) {
    const ok = await this.repo.deleteUser(id);
    if (!ok) {
      throw new ApiError('NOT_FOUND', 'User not found', 404);
    }
    return { success: true };
  }
}
```

### src/controllers/UserController.ts

```ts
import { Request, Response, NextFunction } from "express";
import { autoInjectable } from "tsyringe";
import UserService from "../services/UserService";
import ApiError from "../errors/ApiError";

@autoInjectable()
export default class UserController {
  constructor(private userService?: UserService) {}

  register = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const dto = req.body;
      const user = await this.userService!.registerUser(dto);
      return res.status(201).json({ success: true, data: user });
    } catch (err: any) {
      if (err.message === "User already exists") {
        return next(new ApiError("USER_EXISTS", "User already exists", 409));
      }
      return next(err);
    }
  };

  list = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const users = await this.userService!.listUsers();
      return res.json({ success: true, data: users });
    } catch (err) {
      return next(err);
    }
  };

  getById = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const id = req.params.id;
      const user = await this.userService!.getUserById(id);
      return res.json({ success: true, data: user });
    } catch (err) {
      return next(err);
    }
  };

  update = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const id = req.params.id;
      const payload = req.body;
      const user = await this.userService!.updateUser(id, payload);
      return res.json({ success: true, data: user });
    } catch (err) {
      return next(err);
    }
  };

  delete = async (req: Request, res: Response, next: NextFunction) => {
    try {
      const id = req.params.id;
      const result = await this.userService!.deleteUser(id);
      return res.json(result);
    } catch (err) {
      return next(err);
    }
  };
}
```

### src/routes/users.ts

```ts
import { Router } from "express";
import UserController from "../controllers/UserController";
import { validate } from "../middlewares/validate";
import { CreateUserSchema } from "../dtos/createUser.schema";
import { container } from "tsyringe";

const router = Router();
const controller = container.resolve(UserController);

router.post("/register", validate(CreateUserSchema, "body"), controller.register);
router.get("/", controller.list);
router.get("/:id", controller.getById);
router.put("/:id", validate(CreateUserSchema.partial(), "body"), controller.update);
router.delete("/:id", controller.delete);

export default router;
```

### src/swagger.ts

```ts
import swaggerUi from "swagger-ui-express";
import { OpenAPIV3 } from "openapi-types";

const swaggerSpec: OpenAPIV3.Document = {
  openapi: "3.0.0",
  info: {
    title: "DTO Zod DI Demo API",
    version: "1.0.0",
    description: "Demo API for training: user registration with DTOs, Zod, DI and centralized error handling",
  },
  servers: [{ url: "http://localhost:3000", description: "Local dev server" }],
  components: {
    schemas: {
      CreateUserDTO: {
        type: "object",
        properties: {
          email: { type: "string", format: "email", example: "alice@example.com" },
          password: { type: "string", example: "password123" },
          fullName: { type: "string", nullable: true }
        },
        required: ["email", "password"]
      },
      UserResponse: {
        type: "object",
        properties: {
          id: { type: "string" },
          email: { type: "string", format: "email" },
          fullName: { type: "string", nullable: true }
        }
      },
      ErrorDetail: {
        type: "object",
        properties: {
          path: { type: "string" },
          message: { type: "string" }
        }
      },
      ErrorResponse: {
        type: "object",
        properties: {
          success: { type: "boolean" },
          error: {
            type: "object",
            properties: {
              code: { type: "string" },
              message: { type: "string" },
              details: { type: "array", items: { $ref: "#/components/schemas/ErrorDetail" } }
            }
          }
        }
      }
    }
  },
  paths: {
    "/users/register": {
      post: {
        tags: ["Users"],
        summary: "Register a new user",
        requestBody: {
          required: true,
          content: {
            "application/json": {
              schema: { $ref: "#/components/schemas/CreateUserDTO" }
            }
          }
        },
        responses: {
          "201": {
            description: "User created",
            content: { "application/json": { schema: { type: "object", properties: { success: { type: "boolean" }, data: { $ref: "#/components/schemas/UserResponse" } } } } }
          },
          "400": { description: "Validation error", content: { "application/json": { schema: { $ref: "#/components/schemas/ErrorResponse" } } } },
          "409": { description: "Conflict - user exists", content: { "application/json": { schema: { $ref: "#/components/schemas/ErrorResponse" } } } },
          "500": { description: "Server error", content: { "application/json": { schema: { $ref: "#/components/schemas/ErrorResponse" } } } }
        }
      }
    },
    "/users": {
      get: {
        tags: ["Users"],
        summary: "List users",
        responses: {
          "200": { description: "List", content: { "application/json": { schema: { type: "object", properties: { success: { type: "boolean" }, data: { type: "array", items: { $ref: "#/components/schemas/UserResponse" } } } } } } }
        }
      }
    },
    "/users/{id}": {
      get: {
        tags: ["Users"],
        summary: "Get user by id",
        parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
        responses: {
          "200": { description: "OK", content: { "application/json": { schema: { type: "object", properties: { success: { type: "boolean" }, data: { $ref: "#/components/schemas/UserResponse" } } } } } },
          "404": { description: "Not found", content: { "application/json": { schema: { $ref: "#/components/schemas/ErrorResponse" } } } }
        }
      },
      put: {
        tags: ["Users"],
        summary: "Update user",
        parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
        requestBody: { required: true, content: { "application/json": { schema: { $ref: "#/components/schemas/CreateUserDTO" } } } },
        responses: { "200": { description: "Updated", content: { "application/json": { schema: { type: "object", properties: { success: { type: "boolean" }, data: { $ref: "#/components/schemas/UserResponse" } } } } } }, "404": { description: "Not found", content: { "application/json": { schema: { $ref: "#/components/schemas/ErrorResponse" } } } } }
      },
      delete: {
        tags: ["Users"],
        summary: "Delete user",
        parameters: [{ name: "id", in: "path", required: true, schema: { type: "string" } }],
        responses: { "200": { description: "Deleted", content: { "application/json": { schema: { type: "object", properties: { success: { type: "boolean" } } } } } }, "404": { description: "Not found", content: { "application/json": { schema: { $ref: "#/components/schemas/ErrorResponse" } } } } }
      }
    }
  }
};

export function mountSwagger(app: any) {
  app.use("/docs", swaggerUi.serve, swaggerUi.setup(swaggerSpec));
}

export default swaggerSpec;
```

### src/README.md

(Optionally create a README with the same quick-run instructions provided earlier.)

---

## 3) Run and verify

1. Install packages (if not already):

```cmd
npm install
```

2. Start in dev mode (auto restart on edits):

```cmd
npm run dev
```

3. Verify:
- Visit `http://localhost:3000/docs` to see Swagger UI with endpoints.
- Use curl or Postman to call endpoints. See the "Quick test examples" section earlier in this document.

---

## 4) Tests (suggested)

Add Jest + Supertest for integration tests. Minimal idea:

- Install: `npm install -D jest ts-jest @types/jest supertest @types/supertest`
- Configure jest and add tests in `test/` to call the app.

Example test cases:
- POST /users/register returns 201 and does not contain password in response.
- POST /users/register twice returns 409 with `code: USER_EXISTS`.
- GET /users/:id returns 404 for missing user.

---

## 5) Notes & next steps

- For production, replace the in-memory repo with a DB-backed implementation (Prisma, TypeORM, Sequelize, etc.). Map DB constraint errors to `ApiError` codes.
- Improve logging and add correlation IDs.
- Add authentication (JWT) and authorization errors (401/403) mapping.
- Consider zod-to-openapi generation for keeping schemas in sync with OpenAPI.

---

## 6) File checklist

When you're done, your project should contain these files (at minimum):

- `package.json`
- `tsconfig.json`
- `src/app.ts`
- `src/server.ts`
- `src/container.ts`
- `src/dtos/createUser.schema.ts`
- `src/errors/ApiError.ts`
- `src/middlewares/validate.ts`
- `src/middlewares/errorHandler.ts`
- `src/infra/userRepository.inMemory.ts`
- `src/services/UserService.ts`
- `src/controllers/UserController.ts`
- `src/routes/users.ts`
- `src/swagger.ts`
- `TRAINING.md` (workshop guide)
- `README.md`

---

If you'd like, I can:
- Generate a printable PDF of this guide and place it in the repo. OR
- Add Jest + Supertest tests and run them here. OR
- Scaffold a Prisma schema and DB wiring and show mapping of real DB unique-constraint errors to `ApiError`.

Which follow-up should I implement next? If you want tests, say "Add tests"; for Prisma, say "Add Prisma"; for a PDF, say "Generate PDF".
