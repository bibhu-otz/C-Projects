# DTO + Zod + DI Demo

This is a minimal demo project used in a training session to show:

- DTOs using Zod
- Centralized validation middleware
- Centralized error handling with a standard JSON shape
- Dependency injection using tsyringe

Files are in `src/`. See `TRAINING.md` for the full step-by-step guide and slide notes.

How to run (Windows CMD):

```cmd
npm install
npx ts-node-dev --respawn --transpile-only src/server.ts
```

Then use curl/Postman to call `POST http://localhost:3000/users/register`.
